import asyncio
import aiohttp
import json

class Agent:
    def __init__(self, name, personality):
        self.name = name
        self.personality = personality
        self.memory = []
    
    def create_prompt(self, situation):
        """Create a prompt based on agent's personality and situation."""
        return f"{self.personality}\n\nSituation: {situation}\n\nRespond in one sentence as {self.name}:"

async def ask_llm(session, prompt, url="http://localhost:5001/api/v1/generate"):
    """Send prompt to KoboldCpp and get response."""
    payload = {
        "prompt": prompt,
        "max_context_length": 2048,
        "max_length": 150,
        "temperature": 0.8,
        "top_p": 0.9,
        "top_k": 40
    }
    
    try:
        async with session.post(url, json=payload) as response:
            result = await response.json()
            return result['results'][0]['text'].strip()
    except Exception as e:
        return f"[Error: {e}]"

async def run_simulation():
    """Run a simple agent simulation."""
    
    # Create agents with different personalities
    agents = [
        Agent("Alice", "You are Alice, an optimistic and helpful person."),
        Agent("Bob", "You are Bob, a cautious and analytical person."),
        Agent("Charlie", "You are Charlie, a creative and spontaneous person.")
    ]
    
    # Print agent profiles
    print("\nAGENT PROFILES:")
    print("=" * 60)
    for agent in agents:
        print(f"{agent.personality}")

    # Simulation scenarios
    situations = [
        "You find a mysterious package at your door.",
        "You're invited to explore an abandoned building.",
        "You discover you have one wish that will come true."
    ]
    
    async with aiohttp.ClientSession() as session:
        for round_num, situation in enumerate(situations, 1):
            print(f"\n{'='*60}")
            print(f"ROUND {round_num}: {situation}")
            print('='*60)
            
            # Get all agents' responses concurrently
            tasks = [
                ask_llm(session, agent.create_prompt(situation))
                for agent in agents
            ]
            responses = await asyncio.gather(*tasks)
            
            # Display results
            for agent, response in zip(agents, responses):
                agent.memory.append((situation, response))
                print(f"{agent.name}: {response}")
            
            await asyncio.sleep(1)  # Brief pause between rounds
    
    print(f"\n{'='*60}")
    print("SIMULATION COMPLETE")
    print('='*60)

if __name__ == "__main__":
    print("\nStarting Agent-Based Simulation...")
    print("Make sure KoboldCpp is running on http://localhost:5001")
    asyncio.run(run_simulation())