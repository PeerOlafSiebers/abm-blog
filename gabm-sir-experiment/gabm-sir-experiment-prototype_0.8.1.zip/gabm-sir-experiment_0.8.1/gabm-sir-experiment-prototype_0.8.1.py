"""
SIR Simulation with LLM-driven agent decisions.

To start Koboldcpp:
- Command: koboldcpp --model <your model here> --port 5001
- Example: koboldcpp --model qwen2.5-1.5b-instruct-q6_k.gguf --port 5001
"""

import asyncio
import aiohttp
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from datetime import datetime
import csv
import json
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
import random
from collections import deque
from scipy.spatial import KDTree
import threading
import configparser
from pathlib import Path
from abc import ABC, abstractmethod


# ============================================================================
# CONFIGURATION MODULE
# ============================================================================

@dataclass
class SimulationConfig:
    """Configuration for the entire simulation"""
    # Simulation parameters
    num_agents: int
    initial_infected: int
    recovery_days: int
    max_days: int
    random_seed: int
    
    # Disease parameters
    infection_radius: float
    infection_prob: float
    observation_radius: float
    
    # Movement parameters
    normal_speed: float
    isolated_speed: float
    
    # LLM parameters
    kobold_url: str
    max_concurrent_requests: int
    max_retries: int
    request_timeout: int
    connect_timeout: int
    max_context_length: int
    max_response_length: int
    temperature: float
    top_p: float
    repetition_penalty: float
    
    # Logging parameters
    csv_buffer_size: int
    log_prefix: str
    debug: bool
    
    # Visualisation parameters
    animation_interval: int
    figure_width: int
    figure_height: int
    show_animation: bool
    
    # Connection parameters
    connection_limit: int
    connection_limit_per_host: int
    dns_cache_ttl: int
    force_close_connections: bool
    
    @classmethod
    def from_file(cls, config_path: str = "simulation_config.cfg") -> 'SimulationConfig':
        """Load configuration from file"""
        config = configparser.ConfigParser()
        
        if not Path(config_path).exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")
        
        config.read(config_path)
        
        return cls(
            # Simulation
            num_agents=config.getint('Simulation', 'num_agents'),
            initial_infected=config.getint('Simulation', 'initial_infected'),
            recovery_days=config.getint('Simulation', 'recovery_days'),
            max_days=config.getint('Simulation', 'max_days'),
            random_seed=config.getint('Simulation', 'random_seed'),
            
            # Disease
            infection_radius=config.getfloat('Disease', 'infection_radius'),
            infection_prob=config.getfloat('Disease', 'infection_prob'),
            observation_radius=config.getfloat('Disease', 'observation_radius'),
            
            # Movement
            normal_speed=config.getfloat('Movement', 'normal_speed'),
            isolated_speed=config.getfloat('Movement', 'isolated_speed'),
            
            # LLM
            kobold_url=config.get('LLM', 'kobold_url'),
            max_concurrent_requests=config.getint('LLM', 'max_concurrent_requests'),
            max_retries=config.getint('LLM', 'max_retries'),
            request_timeout=config.getint('LLM', 'request_timeout'),
            connect_timeout=config.getint('LLM', 'connect_timeout'),
            max_context_length=config.getint('LLM', 'max_context_length'),
            max_response_length=config.getint('LLM', 'max_response_length'),
            temperature=config.getfloat('LLM', 'temperature'),
            top_p=config.getfloat('LLM', 'top_p'),
            repetition_penalty=config.getfloat('LLM', 'repetition_penalty'),
            
            # Logging
            csv_buffer_size=config.getint('Logging', 'csv_buffer_size'),
            log_prefix=config.get('Logging', 'log_prefix'),
            debug=config.getboolean('Logging', 'debug'),
            
            # Visualisation
            animation_interval=config.getint('Visualisation', 'animation_interval'),
            figure_width=config.getint('Visualisation', 'figure_width'),
            figure_height=config.getint('Visualisation', 'figure_height'),
            show_animation=config.getboolean('Visualisation', 'show_animation'),
            
            # Connection
            connection_limit=config.getint('Connection', 'connection_limit'),
            connection_limit_per_host=config.getint('Connection', 'connection_limit_per_host'),
            dns_cache_ttl=config.getint('Connection', 'dns_cache_ttl'),
            force_close_connections=config.getboolean('Connection', 'force_close_connections'),
        )
    
    def validate(self):
        """Validate configuration parameters"""
        errors = []
        
        if self.num_agents < self.initial_infected:
            errors.append("initial_infected cannot exceed num_agents")
        
        if not 0 <= self.infection_prob <= 1:
            errors.append("infection_prob must be between 0 and 1")
        
        if not 0 < self.infection_radius <= 1:
            errors.append("infection_radius must be between 0 and 1")
        
        if self.max_concurrent_requests < 1:
            errors.append("max_concurrent_requests must be at least 1")
        
        if errors:
            raise ValueError("Configuration validation failed:\n" + "\n".join(errors))


# ============================================================================
# AGENT MODULE
# ============================================================================

# Persona profiles
PERSONAS = [
    "Cautious healthcare worker, isolates early",
    "Young optimist, values social connections",
    "Parent balancing work and family safety",
    "Elderly with health concerns, very cautious",
    "Sceptical of warnings, values freedom",
    "Data-driven scientist",
    "Social person, finds isolation difficult",
    "Essential worker balancing safety and economics",
]


@dataclass
class Agent:
    """Individual agent with state and behaviour"""
    id: int
    x: float
    y: float
    state: str  # 'S', 'I', 'R'
    persona: str
    days_infected: int = 0
    will_isolate: bool = False
    
    def get_position(self) -> np.ndarray:
        """Return position as numpy array"""
        return np.array([self.x, self.y])
    
    def move(self, speed: float):
        """Move agent randomly within bounds"""
        self.x += random.uniform(-speed, speed)
        self.y += random.uniform(-speed, speed)
        self.x = np.clip(self.x, 0, 1)
        self.y = np.clip(self.y, 0, 1)
    
    def progress_infection(self, recovery_days: int) -> bool:
        """Progress infection state, return True if recovered"""
        if self.state == 'I':
            self.days_infected += 1
            if self.days_infected >= recovery_days:
                self.state = 'R'
                self.days_infected = 0
                self.will_isolate = False
                return True
        return False
    
    def infect(self):
        """Transition to infected state"""
        self.state = 'I'
        self.days_infected = 0


# ============================================================================
# SPATIAL INDEXING MODULE
# ============================================================================

class SpatialIndex:
    """Efficient spatial queries using KDTree"""
    
    def __init__(self, agents: List[Agent]):
        self.agents = agents
        self.tree: Optional[KDTree] = None
        self._lock = asyncio.Lock()
        self.rebuild()
    
    def rebuild(self):
        """Rebuild spatial index from current agent positions"""
        positions = np.array([[a.x, a.y] for a in self.agents])
        self.tree = KDTree(positions)
    
    def query_radius(self, agent: Agent, radius: float) -> List[Agent]:
        """Find all agents within radius of given agent"""
        if self.tree is None:
            self.rebuild()
        
        indices = self.tree.query_ball_point([agent.x, agent.y], radius)
        return [self.agents[i] for i in indices if self.agents[i].id != agent.id]
    
    def get_neighbourhood_stats(self, agent: Agent, radius: float) -> Dict[str, int]:
        """Get statistics about nearby agents"""
        nearby = self.query_radius(agent, radius)
        stats = {
            'total': len(nearby),
            'infected': sum(1 for a in nearby if a.state == 'I'),
            'susceptible': sum(1 for a in nearby if a.state == 'S'),
            'recovered': sum(1 for a in nearby if a.state == 'R')
        }
        return stats


# ============================================================================
# DISEASE DYNAMICS MODULE
# ============================================================================

class DiseaseModel:
    """Handles disease spread and state transitions"""
    
    def __init__(self, config: SimulationConfig, spatial_index: SpatialIndex):
        self.config = config
        self.spatial_index = spatial_index
    
    def spread_infection(self, agents: List[Agent]) -> int:
        """Spread infection between nearby agents, return new infection count"""
        new_infections = []
        
        infected_agents = [a for a in agents if a.state == 'I' and not a.will_isolate]
        
        for inf_agent in infected_agents:
            nearby = self.spatial_index.query_radius(inf_agent, self.config.infection_radius)
            
            for other in nearby:
                if other.state == 'S' and not other.will_isolate:
                    if random.random() < self.config.infection_prob:
                        new_infections.append(other)
        
        for agent in new_infections:
            agent.infect()
        
        return len(new_infections)
    
    def update_states(self, agents: List[Agent]) -> int:
        """Update agent infection states, return recovery count"""
        recoveries = sum(1 for a in agents if a.progress_infection(self.config.recovery_days))
        return recoveries
    
    def move_agents(self, agents: List[Agent]):
        """Move all agents based on isolation status"""
        for agent in agents:
            speed = self.config.isolated_speed if agent.will_isolate else self.config.normal_speed
            agent.move(speed)


# ============================================================================
# LLM CLIENT MODULE
# ============================================================================

class LLMClient:
    """Persistent LLM client with connection pooling and thread-safe initialization"""
    
    def __init__(self, config: SimulationConfig):
        self.config = config
        self.semaphore = asyncio.Semaphore(config.max_concurrent_requests)
        self.session: Optional[aiohttp.ClientSession] = None
        self._session_lock = asyncio.Lock()
        self._closed = False
        
        # Statistics tracking
        self.stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'error_requests': 0,
            'default_decisions': 0,
            'error_types': {},
            'response_types': {
                'YES': 0,
                'NO': 0,
                'UNCLEAR': 0,
                'ERROR': 0
            }
        }
    
    async def __aenter__(self):
        await self.start()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
    
    async def start(self):
        """Thread-safe session initialization"""
        async with self._session_lock:
            if self.session is None and not self._closed:
                timeout = aiohttp.ClientTimeout(
                    total=self.config.request_timeout,
                    connect=self.config.connect_timeout
                )
                connector = aiohttp.TCPConnector(
                    limit=self.config.connection_limit,
                    limit_per_host=self.config.connection_limit_per_host,
                    ttl_dns_cache=self.config.dns_cache_ttl,
                    force_close=self.config.force_close_connections
                )
                self.session = aiohttp.ClientSession(
                    connector=connector,
                    timeout=timeout,
                    headers={
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                )
    
    async def close(self):
        """Thread-safe session cleanup"""
        async with self._session_lock:
            if self.session and not self._closed:
                await self.session.close()
                self.session = None
                self._closed = True
    
    def create_prompt(self, agent: Agent, stats: Dict[str, int]) -> str:
        """Create prompt for agent decision"""
        return f"""{agent.persona}

Nearby: {stats['total']} people, {stats['infected']} infected.
Should you isolate? Reply: YES/NO then reason briefly.
Answer:"""
    
    def parse_response(self, response: str, nearby_infected: int) -> Tuple[bool, str]:
        """Parse LLM response and extract decision"""
        self.stats['total_requests'] += 1
        
        if response.startswith("ERROR:"):
            self.stats['error_requests'] += 1
            self.stats['default_decisions'] += 1
            error_type = response.split(':')[1] if ':' in response else 'Unknown'
            self.stats['error_types'][error_type] = self.stats['error_types'].get(error_type, 0) + 1
            self.stats['response_types']['ERROR'] += 1
            
            decision = nearby_infected > 1
            return decision, f"Default (LLM error: {response})"
        
        response_upper = response.upper()
        first_50 = response_upper[:50]
        
        if 'YES' in first_50:
            self.stats['successful_requests'] += 1
            self.stats['response_types']['YES'] += 1
            return True, response[:150]
        elif 'NO' in first_50:
            self.stats['successful_requests'] += 1
            self.stats['response_types']['NO'] += 1
            return False, response[:150]
        else:
            self.stats['successful_requests'] += 1
            self.stats['default_decisions'] += 1
            self.stats['response_types']['UNCLEAR'] += 1
            decision = nearby_infected > 2
            return decision, f"Unclear response, default: {response[:100]}"
        
    async def query(self, prompt: str) -> str:
        """Query LLM with retry logic and proper session handling"""
        if not self.session:
            await self.start()
        
        payload = {
            "prompt": prompt,
            "max_context_length": self.config.max_context_length,
            "max_length": self.config.max_response_length,
            "temperature": self.config.temperature,
            "top_p": self.config.top_p,
            "rep_pen": self.config.repetition_penalty,
            "stop_sequence": ["\n\n", "###"]
        }
        
        async with self.semaphore:
            for attempt in range(self.config.max_retries + 1):
                try:
                    if not self.session:
                        await self.start()
                    
                    async with self.session.post(
                        f"{self.config.kobold_url}/api/v1/generate",
                        json=payload
                    ) as response:
                        if response.status != 200:
                            raise aiohttp.ClientError(f"Status {response.status}")
                        
                        data = await response.json()
                        text = data['results'][0]['text'].strip()
                        
                        if not text:
                            raise ValueError("Empty response")
                        
                        return text
                
                except (aiohttp.ClientError, ValueError, KeyError, asyncio.TimeoutError) as e:
                    error_type = type(e).__name__
                    if attempt < self.config.max_retries:
                        await asyncio.sleep(0.3 * (attempt + 1))
                        continue
                    return f"ERROR:{error_type}"
            
            return "ERROR:MaxRetries"
    
    def get_statistics(self) -> Dict:
        """Get comprehensive LLM statistics with thread-safe access"""
        # Create a deep copy of current stats to avoid race conditions
        stats_snapshot = {
            'total_requests': self.stats['total_requests'],
            'successful_requests': self.stats['successful_requests'],
            'error_requests': self.stats['error_requests'],
            'default_decisions': self.stats['default_decisions'],
            'error_types': dict(self.stats['error_types']),  # Force copy
            'response_types': dict(self.stats['response_types'])  # Force copy
        }
        
        # Calculate percentages with zero division protection
        total = stats_snapshot['total_requests']
        
        if total > 0:
            stats_snapshot['success_rate'] = (stats_snapshot['successful_requests'] / total) * 100
            stats_snapshot['error_rate'] = (stats_snapshot['error_requests'] / total) * 100
            stats_snapshot['default_rate'] = (stats_snapshot['default_decisions'] / total) * 100
        else:
            stats_snapshot['success_rate'] = 0.0
            stats_snapshot['error_rate'] = 0.0
            stats_snapshot['default_rate'] = 0.0
        
        # Calculate response type percentages
        response_types_copy = stats_snapshot['response_types'].copy()
        for response_type in ['YES', 'NO', 'UNCLEAR', 'ERROR']:
            count = response_types_copy.get(response_type, 0)
            rate_key = f'{response_type}_rate'
            if total > 0:
                response_types_copy[rate_key] = (count / total) * 100
            else:
                response_types_copy[rate_key] = 0.0
        
        stats_snapshot['response_types'] = response_types_copy
        
        return stats_snapshot

# ============================================================================
# DECISION MAKER MODULE
# ============================================================================

class DecisionMaker:
    """Handles agent decision-making logic"""
    
    def __init__(self, config: SimulationConfig, llm_client: LLMClient, spatial_index: SpatialIndex):
        self.config = config
        self.llm_client = llm_client
        self.spatial_index = spatial_index
    
    async def make_decision(self, agent: Agent) -> Tuple[bool, Dict[str, int], str]:
        """Agent makes isolation decision via LLM"""
        if agent.state != 'S':
            return False, {}, "Not susceptible"
        
        # Get neighbourhood statistics
        stats = self.spatial_index.get_neighbourhood_stats(agent, self.config.observation_radius)
        
        # Create prompt and query LLM
        prompt = self.llm_client.create_prompt(agent, stats)
        response = await self.llm_client.query(prompt)
        
        # Parse decision
        decision, reasoning = self.llm_client.parse_response(response, stats['infected'])
        
        return decision, stats, reasoning


# ============================================================================
# LOGGING MODULE
# ============================================================================

class CSVLogger:
    """Buffered CSV logger with async-safe synchronization"""
    
    def __init__(self, config: SimulationConfig):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.filename = f"{config.log_prefix}_{timestamp}.csv"
        self.buffer_size = config.csv_buffer_size
        self.buffer: List[List] = []  # Fix: Use list instead of deque with maxlen
        self.lock = asyncio.Lock()  # Fix: Use asyncio.Lock
        self._entries_dropped = 0
        
        # Write header
        with open(self.filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow([
                'Day', 'Agent_ID', 'State', 'Persona',
                'Nearby_Total', 'Nearby_Infected',
                'Decision', 'Reasoning'
            ])
    
    async def log(self, day: int, agent: Agent, stats: Dict[str, int], decision: bool, reasoning: str):
        """Async-safe log entry"""
        async with self.lock:
            clean_reasoning = reasoning.replace('\n', ' ').replace('\r', ' ')[:200]
            
            self.buffer.append([
                day, agent.id, agent.state, agent.persona[:50],
                stats.get('total', 0), stats.get('infected', 0),
                decision, clean_reasoning
            ])
            
            # Auto-flush if buffer full
            if len(self.buffer) >= self.buffer_size:
                await self._flush_internal()
    
    async def _flush_internal(self):
        """Internal flush without acquiring lock (already held)"""
        if not self.buffer:
            return
        
        # Use asyncio to_thread for blocking I/O
        try:
            await asyncio.to_thread(self._write_buffer)
        except Exception as e:
            print(f"⚠ Error flushing CSV: {e}")
            self._entries_dropped += len(self.buffer)
        finally:
            self.buffer.clear()
    
    def _write_buffer(self):
        """Blocking write operation (runs in thread pool)"""
        with open(self.filename, 'a', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerows(self.buffer)
    
    async def flush(self):
        """Public flush method"""
        async with self.lock:
            await self._flush_internal()
    
    def get_stats(self) -> Dict:
        """Get logging statistics"""
        return {
            'entries_buffered': len(self.buffer),
            'entries_dropped': self._entries_dropped
        }


# ============================================================================
# SIMULATION STATISTICS MODULE
# ============================================================================

class SimulationStatistics:
    """Track simulation statistics over time with thread-safe access"""
    
    def __init__(self):
        self.history = {
            'S': [],
            'I': [],
            'R': [],
            'Isolated': []
        }
        self.day = 0
        self._lock = asyncio.Lock()  # Fix: Add lock for thread safety
    
    async def update(self, agents: List[Agent]) -> Dict:
        """Thread-safe update"""
        async with self._lock:
            counts = {'S': 0, 'I': 0, 'R': 0, 'Isolated': 0}
            
            for agent in agents:
                counts[agent.state] += 1
                if agent.will_isolate and agent.state == 'S':
                    counts['Isolated'] += 1
            
            for key in ['S', 'I', 'R', 'Isolated']:
                self.history[key].append(counts[key])
            
            self.day += 1
            return counts
    
    async def get_latest(self, key: str) -> Optional[int]:
        """Thread-safe access to latest value"""
        async with self._lock:
            if key in self.history and len(self.history[key]) > 0:
                return self.history[key][-1]
            return None
    
    async def has_infections(self) -> bool:
        """Check if infections exist (thread-safe)"""
        async with self._lock:
            # Check if we have history and if the last entry has infections
            if 'I' not in self.history or len(self.history['I']) == 0:
                return False
            return self.history['I'][-1] > 0
    
    def get_history_copy(self) -> Dict:
        """Get a copy of history for visualization (synchronous, for thread access)"""
        # Note: This is intentionally synchronous for matplotlib compatibility
        return {
            key: list(values)  # Create copies
            for key, values in self.history.items()
        }


# ============================================================================
# SIMULATION CORE MODULE
# ============================================================================

class SIRSimulation:
    """Core simulation orchestrator with proper error handling"""
    
    def __init__(self, config: SimulationConfig):
        self.config = config
        
        # Set random seed if specified
        if config.random_seed != 0:
            random.seed(config.random_seed)
            np.random.seed(config.random_seed)
        
        # Initialise statistics first (needed by _create_agents)
        self.stats = SimulationStatistics()
        
        # Initialise agents
        self.agents = self._create_agents()
        
        # Core components
        self.spatial_index = SpatialIndex(self.agents)
        self.disease_model = DiseaseModel(config, self.spatial_index)
        self.llm_client = LLMClient(config)
        self.decision_maker = DecisionMaker(config, self.llm_client, self.spatial_index)
        self.logger = CSVLogger(config)
        
        # Runtime state
        self.running = False
        self._simulation_lock = asyncio.Lock()
        self._decision_failures = 0
        self._max_failure_rate = 0.5
        
        # Enhanced statistics
        self.simulation_stats = {
            'total_days': 0,
            'total_decisions': 0,
            'decision_failures': 0,
            'isolation_decisions': 0,
            'no_isolation_decisions': 0,
            'persona_decisions': {},
            # Add runtime statistics
            'start_time': None,
            'end_time': None,
            'total_simulation_time': 0,
            'average_day_time': 0,
            'total_llm_time': 0,
            'average_llm_request_time': 0
        }

    def _create_agents(self) -> List[Agent]:
        """Create initial agent population"""
        agents = []
        for i in range(self.config.num_agents):
            state = 'I' if i < self.config.initial_infected else 'S'
            persona = PERSONAS[i % len(PERSONAS)]
            agent = Agent(
                id=i,
                x=random.random(),
                y=random.random(),
                state=state,
                persona=persona
            )
            agents.append(agent)
        
        counts = {'S': 0, 'I': 0, 'R': 0, 'Isolated': 0}
        for agent in agents:
            counts[agent.state] += 1
            if agent.will_isolate and agent.state == 'S':
                counts['Isolated'] += 1
        
        for key in ['S', 'I', 'R', 'Isolated']:
            self.stats.history[key].append(counts[key])
        
        return agents
    
    async def simulate_day(self):
        """Run one day of simulation with proper error handling"""
        async with self._simulation_lock:
            day_start_time = asyncio.get_event_loop().time()
            print(f"\n=== Day {self.stats.day} ===")
            
            # Phase 1: Rebuild spatial index (atomic operation)
            self.spatial_index.rebuild()
            
            # Phase 2: Decision making with validation
            susceptible = [a for a in self.agents if a.state == 'S']
            day_llm_time = 0  # Initialize to avoid reference before assignment
            
            if susceptible:
                llm_start_time = asyncio.get_event_loop().time()
                decisions = await asyncio.gather(
                    *[self.decision_maker.make_decision(a) for a in susceptible],
                    return_exceptions=True
                )
                llm_end_time = asyncio.get_event_loop().time()
                day_llm_time = llm_end_time - llm_start_time
                self.simulation_stats['total_llm_time'] += day_llm_time
                
                failures = 0
                successes = 0
                day_isolation_decisions = 0
                day_no_isolation_decisions = 0
                
                for agent, result in zip(susceptible, decisions):
                    if isinstance(result, Exception):
                        print(f"⚠ Agent {agent.id} decision failed: {result}")
                        agent.will_isolate = False
                        failures += 1
                        self._decision_failures += 1
                        self.simulation_stats['decision_failures'] += 1
                    else:
                        decision, stats, reasoning = result
                        agent.will_isolate = decision
                        await self.logger.log(self.stats.day, agent, stats, decision, reasoning)
                        successes += 1
                        self.simulation_stats['total_decisions'] += 1
                        
                        # Track isolation decisions
                        if decision:
                            day_isolation_decisions += 1
                            self.simulation_stats['isolation_decisions'] += 1
                        else:
                            day_no_isolation_decisions += 1
                            self.simulation_stats['no_isolation_decisions'] += 1
                        
                        # Track persona decisions
                        if agent.persona not in self.simulation_stats['persona_decisions']:
                            self.simulation_stats['persona_decisions'][agent.persona] = {
                                'total': 0,
                                'isolate': 0,
                                'no_isolate': 0
                            }
                        self.simulation_stats['persona_decisions'][agent.persona]['total'] += 1
                        if decision:
                            self.simulation_stats['persona_decisions'][agent.persona]['isolate'] += 1
                        else:
                            self.simulation_stats['persona_decisions'][agent.persona]['no_isolate'] += 1
                
                # Update simulation stats
                self.simulation_stats['total_days'] = self.stats.day + 1
                
                failure_rate = failures / len(susceptible) if susceptible else 0
                if failure_rate > self._max_failure_rate:
                    raise RuntimeError(
                        f"Decision failure rate too high: {failure_rate:.1%} "
                        f"({failures}/{len(susceptible)}). Aborting simulation."
                    )
                
                if failures > 0:
                    print(f"⚠ {failures} decision failures, {successes} successes")
                
                if day_isolation_decisions > 0 or day_no_isolation_decisions > 0:
                    print(f"  Isolation decisions: {day_isolation_decisions} YES, {day_no_isolation_decisions} NO")
            
            # Phase 3: Disease dynamics (only if decisions succeeded)
            new_infections = self.disease_model.spread_infection(self.agents)
            recoveries = self.disease_model.update_states(self.agents)
            self.disease_model.move_agents(self.agents)
            
            # Phase 4: Update statistics
            counts = await self.stats.update(self.agents)
            
            # Calculate day runtime
            day_end_time = asyncio.get_event_loop().time()
            day_runtime = day_end_time - day_start_time
            self.simulation_stats['total_simulation_time'] += day_runtime
            
            print(f"  S:{counts['S']} I:{counts['I']} R:{counts['R']} Isolating:{counts['Isolated']}")
            if new_infections > 0:
                print(f"  New infections: {new_infections}")
            if recoveries > 0:
                print(f"  Recoveries: {recoveries}")
            
            # Print day runtime if in debug mode
            if self.config.debug:
                print(f"  Day runtime: {day_runtime:.2f}s (LLM: {day_llm_time:.2f}s)")

    async def run_async(self):
        """Run simulation asynchronously with proper cleanup"""
        print(f"Starting simulation: {self.config.num_agents} agents, {self.config.max_days} days")
        print(f"LLM: {self.config.kobold_url}")
        
        # Record start time
        self.simulation_stats['start_time'] = asyncio.get_event_loop().time()
        
        initial_infected = sum(1 for a in self.agents if a.state == 'I')
        print(f"Initial infected count: {initial_infected}")
        print(f"Stats history I: {self.stats.history['I']}\n")
        
        self.running = True
        day_count = 0
        
        try:
            async with self.llm_client:
                while self.running and day_count < self.config.max_days:
                    try:
                        await self.simulate_day()
                        day_count += 1
                    except RuntimeError as e:
                        print(f"\n❌ Simulation error: {e}")
                        break
                    
                    has_infections = await self.stats.has_infections()
                    if not has_infections:
                        print("\nNo more infections. Simulation ending.")
                        break
                    
                    await asyncio.sleep(0.1)
            
            # Record end time
            self.simulation_stats['end_time'] = asyncio.get_event_loop().time()
            
            # Calculate final runtime statistics
            if self.simulation_stats['start_time'] and self.simulation_stats['end_time']:
                total_time = self.simulation_stats['end_time'] - self.simulation_stats['start_time']
                self.simulation_stats['total_simulation_time'] = total_time
            
            # Calculate averages
            if self.simulation_stats['total_days'] > 0:
                self.simulation_stats['average_day_time'] = (
                    self.simulation_stats['total_simulation_time'] / self.simulation_stats['total_days']
                )
            
            if self.simulation_stats['total_decisions'] > 0:
                self.simulation_stats['average_llm_request_time'] = (
                    self.simulation_stats['total_llm_time'] / self.simulation_stats['total_decisions']
                )
            
            await self.logger.flush()
            
            # Print enhanced summary statistics
            await self._print_statistics_summary()
        
        except Exception as e:
            print(f"\n❌ Unexpected error: {e}")
            import traceback
            traceback.print_exc()
            raise
        finally:
            await self.logger.flush()
            self.running = False

    async def _print_statistics_summary(self):
        """Print comprehensive statistics at simulation end"""
        print(f"\n{'='*60}")
        print("SIMULATION STATISTICS SUMMARY")
        print(f"{'='*60}")
        
        # Basic simulation stats
        print(f"\nSimulation Overview:")
        print(f"  Days simulated: {self.simulation_stats['total_days']}")
        print(f"  Total agents: {len(self.agents)}")
        print(f"  Final S: {await self.stats.get_latest('S')}, I: {await self.stats.get_latest('I')}, R: {await self.stats.get_latest('R')}")
        
        # Runtime statistics
        print(f"Runtime Statistics:")
        print(f"  Total simulation time: {self.simulation_stats['total_simulation_time'] / 60:.2f} minutes")
        print(f"  Average time per day: {self.simulation_stats['average_day_time'] / 60:.2f} minutes")
        print(f"  Total LLM processing time: {self.simulation_stats['total_llm_time'] / 60:.2f} minutes")
        if self.simulation_stats['total_decisions'] > 0:
            print(f"  Average LLM request time: {self.simulation_stats['average_llm_request_time'] / 60:.2f} minutes")
        
        # LLM statistics
        llm_stats = self.llm_client.get_statistics()
        print(f"LLM Communication Statistics:")
        print(f"  Total requests: {llm_stats['total_requests']}")
        print(f"  Successful: {llm_stats['successful_requests']} ({llm_stats['success_rate']:.1f}%)")
        print(f"  Errors: {llm_stats['error_requests']} ({llm_stats['error_rate']:.1f}%)")
        print(f"  Default decisions: {llm_stats['default_decisions']} ({llm_stats['default_rate']:.1f}%)")
        
        # Response type breakdown
        print(f"  Response Types:")
        for response_type, count in llm_stats['response_types'].items():
            if not response_type.endswith('_rate'):
                rate_key = f"{response_type}_rate"
                rate = llm_stats['response_types'].get(rate_key, 0)
                print(f"    {response_type}: {count} ({rate:.1f}%)")
        
        # Error type breakdown
        if llm_stats['error_types']:
            print(f"  Error Types:")
            for error_type, count in llm_stats['error_types'].items():
                percentage = (count / llm_stats['total_requests']) * 100
                print(f"    {error_type}: {count} ({percentage:.1f}%)")
        
        # Decision statistics
        print(f"Decision Statistics:")
        print(f"  Total decisions made: {self.simulation_stats['total_decisions']}")
        print(f"  Decision failures: {self.simulation_stats['decision_failures']}")
        if self.simulation_stats['total_decisions'] > 0:
            failure_rate = (self.simulation_stats['decision_failures'] / 
                          (self.simulation_stats['total_decisions'] + self.simulation_stats['decision_failures'])) * 100
            print(f"  Decision failure rate: {failure_rate:.1f}%")
        
        print(f"  Isolation decisions: {self.simulation_stats['isolation_decisions']} YES, "
              f"{self.simulation_stats['no_isolation_decisions']} NO")
        
        if self.simulation_stats['total_decisions'] > 0:
            isolation_rate = (self.simulation_stats['isolation_decisions'] / 
                            self.simulation_stats['total_decisions']) * 100
            print(f"  Overall isolation rate: {isolation_rate:.1f}%")
        
        # Persona statistics
        if self.simulation_stats['persona_decisions']:
            print(f"Persona Decision Patterns:")
            for persona, stats in self.simulation_stats['persona_decisions'].items():
                if stats['total'] > 0:
                    isolate_rate = (stats['isolate'] / stats['total']) * 100
                    print(f"  {persona[:50]:<50} - "
                          f"Isolate: {stats['isolate']}/{stats['total']} ({isolate_rate:.1f}%)")
        
        # Connection statistics
        print(f"Connection Statistics:")
        print(f"  Max concurrent requests: {self.config.max_concurrent_requests}")
        print(f"  Max retries per request: {self.config.max_retries}")
        print(f"  Request timeout: {self.config.request_timeout}s")
        
        logger_stats = self.logger.get_stats()
        if logger_stats['entries_dropped'] > 0:
            print(f"\nCSV entries dropped: {logger_stats['entries_dropped']}")
        
        print(f"{'='*60}")


# ============================================================================
# VISUALISATION MODULE
# ============================================================================

class SimulationVisualiser:
    """Handles matplotlib visualisation with thread-safe state access"""
    
    def __init__(self, simulation: SIRSimulation):
        self.sim = simulation
        self.config = simulation.config
        
        # Fix: Cache for thread-safe access
        self._agent_states_cache = []
        self._stats_cache = {}
        self._cache_lock = threading.Lock()
        
        self.fig, (self.ax1, self.ax2, self.ax3) = plt.subplots(
            1, 3, 
            figsize=(self.config.figure_width, self.config.figure_height)
        )
        self.setup_plots()
    
    def setup_plots(self):
        """Initialise plot layout"""
        self.ax1.set_xlim(0, 1)
        self.ax1.set_ylim(0, 1)
        self.ax1.set_title('Agent Positions and States')
        
        self.ax2.set_title('SIR Model Over Time')
        self.ax2.set_xlabel('Day')
        self.ax2.set_ylabel('Count')
        
        self.ax3.set_title('Isolation Behaviour')
        self.ax3.set_xlabel('Day')
        self.ax3.set_ylabel('Isolating Count')
        
        plt.tight_layout()
    
    def update_cache(self):
        """Update cache from simulation (called periodically)"""
        with self._cache_lock:
            # Fix: Deep copy current state to avoid race conditions
            self._agent_states_cache = [
                {
                    'x': a.x,
                    'y': a.y,
                    'state': a.state,
                    'will_isolate': a.will_isolate
                }
                for a in self.sim.agents
            ]
            self._stats_cache = self.sim.stats.get_history_copy()
    
    def update(self, frame):
        """Update all plots from cached data"""
        # Update cache
        self.update_cache()
        
        # Get cached data
        with self._cache_lock:
            agent_states = list(self._agent_states_cache)  # Copy
            stats = dict(self._stats_cache)  # Copy
        
        for ax in [self.ax1, self.ax2, self.ax3]:
            ax.clear()
        
        # Agent positions from cache
        state_colors = {'S': 'blue', 'I': 'red', 'R': 'green'}
        for state, color in state_colors.items():
            agents_in_state = [a for a in agent_states if a['state'] == state]
            if agents_in_state:
                self.ax1.scatter(
                    [a['x'] for a in agents_in_state],
                    [a['y'] for a in agents_in_state],
                    c=color, label=state, s=50, alpha=0.6
                )
        
        # Highlight isolated agents
        isolated = [a for a in agent_states if a['will_isolate'] and a['state'] == 'S']
        if isolated:
            self.ax1.scatter(
                [a['x'] for a in isolated],
                [a['y'] for a in isolated],
                s=200, facecolors='none', edgecolors='black',
                linewidths=2, label='Isolating'
            )
        
        self.ax1.set_xlim(0, 1)
        self.ax1.set_ylim(0, 1)
        self.ax1.set_title(f'Day {self.sim.stats.day}')
        self.ax1.legend()
        
        # SIR curves from cache
        if stats and len(stats.get('S', [])) > 0:
            days = range(len(stats['S']))
            self.ax2.plot(days, stats['S'], 'b-', label='S', linewidth=2)
            self.ax2.plot(days, stats['I'], 'r-', label='I', linewidth=2)
            self.ax2.plot(days, stats['R'], 'g-', label='R', linewidth=2)
            self.ax2.legend()
            self.ax2.grid(True, alpha=0.3)
            
            # Isolation trend
            self.ax3.plot(days, stats['Isolated'], 'purple', linewidth=2)
            self.ax3.fill_between(days, stats['Isolated'], alpha=0.3, color='purple')
            self.ax3.grid(True, alpha=0.3)
        
        plt.tight_layout()
    
    def run_with_animation(self):
        """Run simulation in separate thread with proper async handling"""
        import threading
        import queue
        
        # Queue for communication between threads
        self._update_queue = queue.Queue()
        self._simulation_running = True
        
        def run_simulation():
            """Run simulation in background thread"""
            try:
                # Create new event loop for this thread
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                async def run_sim():
                    await self.sim.run_async()
                    self._update_queue.put("COMPLETE")
                
                loop.run_until_complete(run_sim())
                loop.close()
                
            except Exception as e:
                print(f"Simulation error in thread: {e}")
                self._update_queue.put("ERROR")
        
        # Start simulation in background thread
        sim_thread = threading.Thread(target=run_simulation, daemon=True)
        sim_thread.start()
        
        print("Simulation started in background thread...")
        
        # Animation function
        def animate(frame):
            try:
                # Check for simulation updates (non-blocking)
                try:
                    msg = self._update_queue.get_nowait()
                    if msg == "COMPLETE":
                        print("Simulation complete!")
                        return
                    elif msg == "ERROR":
                        print("Simulation error detected!")
                        return
                except queue.Empty:
                    pass
                
                # Update visualization with current simulation state
                self.update_cache()
                
                # Clear and redraw plots
                self.ax1.clear()
                self.ax2.clear() 
                self.ax3.clear()
                
                # Get cached data
                with self._cache_lock:
                    agent_states = list(self._agent_states_cache)
                    stats = dict(self._stats_cache)
                
                # Plot agent positions
                state_colors = {'S': 'blue', 'I': 'red', 'R': 'green'}
                for state, color in state_colors.items():
                    agents_in_state = [a for a in agent_states if a['state'] == state]
                    if agents_in_state:
                        self.ax1.scatter(
                            [a['x'] for a in agents_in_state],
                            [a['y'] for a in agents_in_state],
                            c=color, label=state, s=50, alpha=0.6
                        )
                
                # Highlight isolated agents
                isolated = [a for a in agent_states if a['will_isolate'] and a['state'] == 'S']
                if isolated:
                    self.ax1.scatter(
                        [a['x'] for a in isolated],
                        [a['y'] for a in isolated],
                        s=200, facecolors='none', edgecolors='black',
                        linewidths=2, label='Isolating'
                    )
                
                self.ax1.set_xlim(0, 1)
                self.ax1.set_ylim(0, 1)
                self.ax1.set_title(f'Agent Positions - Day {self.sim.stats.day}')
                self.ax1.legend()
                
                # Plot SIR curves
                if stats and len(stats.get('S', [])) > 0:
                    days = range(len(stats['S']))
                    self.ax2.plot(days, stats['S'], 'b-', label='S', linewidth=2)
                    self.ax2.plot(days, stats['I'], 'r-', label='I', linewidth=2)
                    self.ax2.plot(days, stats['R'], 'g-', label='R', linewidth=2)
                    self.ax2.set_title('SIR Model Over Time')
                    self.ax2.set_xlabel('Day')
                    self.ax2.set_ylabel('Count')
                    self.ax2.legend()
                    self.ax2.grid(True, alpha=0.3)
                    
                    # Plot isolation trend
                    self.ax3.plot(days, stats['Isolated'], 'purple', linewidth=2, label='Isolating')
                    self.ax3.fill_between(days, stats['Isolated'], alpha=0.3, color='purple')
                    self.ax3.set_title('Isolation Behaviour')
                    self.ax3.set_xlabel('Day')
                    self.ax3.set_ylabel('Isolating Count')
                    self.ax3.legend()
                    self.ax3.grid(True, alpha=0.3)
                
                plt.tight_layout()
                
            except Exception as e:
                print(f"Animation error: {e}")
        
        # Create animation
        anim = FuncAnimation(
            self.fig,
            animate,
            interval=self.config.animation_interval,
            repeat=True,
            cache_frame_data=False
        )
        
        plt.show()
        
        # Cleanup
        self._simulation_running = False
# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

async def main_async(config_path: str = "gabm-sir-experiment-prototype.cfg"):
    """Async main entry point with proper cleanup"""
    simulation = None
    visualiser = None
    
    try:
        # Load and validate configuration
        print("Loading configuration...")
        config = SimulationConfig.from_file(config_path)
        config.validate()
        print(f"Configuration loaded: {config.num_agents} agents, {config.max_days} days")
        
        # Create simulation
        print("\nInitialising simulation...")
        simulation = SIRSimulation(config)
        print(f"Created {len(simulation.agents)} agents")
        print(f"Initial infections: {config.initial_infected}")
        print(f"LLM endpoint: {config.kobold_url}")
        
        # Run simulation
        if config.show_animation:
            print("\nStarting simulation with live visualisation...")
            visualiser = SimulationVisualiser(simulation)
            visualiser.run_with_animation()
        else:
            print("\nStarting headless simulation...")
            await simulation.run_async()
        
        print("Simulation complete!")
        print(f"Results saved to: {simulation.logger.filename}")
        
        return 0
        
    except FileNotFoundError as e:
        print(f"Error: {e}")
        print("Please ensure gabm-sir-experiment-prototype.cfg exists in the current directory.")
        return 1
    except ValueError as e:
        print(f"Configuration Error: {e}")
        return 1
    except KeyboardInterrupt:
        print("\nSimulation interrupted by user.")
        return 130
    except Exception as e:
        print(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return 1
    finally:
        # Fix: Ensure cleanup happens
        if simulation:
            print("\nCleaning up resources...")
            try:
                await simulation.logger.flush()
                await simulation.llm_client.close()
                print("Resources cleaned up")
            except Exception as e:
                print(f"Error during cleanup: {e}")


def main(config_path: str = "gabm-sir-experiment-prototype.cfg"):
    """Main entry point for the simulation"""
    try:
        # Use asyncio.run for proper async handling
        exit_code = asyncio.run(main_async(config_path))
        return exit_code
        
    except KeyboardInterrupt:
        print("\nSimulation interrupted by user.")
        return 130
    except Exception as e:
        print(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    import sys
    
    # Allow config file path as command-line argument
    config_file = sys.argv[1] if len(sys.argv) > 1 else "gabm-sir-experiment-prototype.cfg"
    
    exit_code = main(config_file)
    sys.exit(exit_code)