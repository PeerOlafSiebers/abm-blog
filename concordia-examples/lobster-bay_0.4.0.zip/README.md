# Lobster Bay: a commons dilemma with Concordia

Lobster Bay is a small generative agent-based model (GABM) built with
[Concordia](https://github.com/google-deepmind/concordia) (`gdm-concordia`).
Three LLM-driven fishers share one bay. Every day each fisher decides how many
lobster traps to set (0 to 10). The lobster stock, the catches and the money
are grounded variables kept in Python. The fishers only see a vague, textual
impression of the bay, so nobody knows the exact stock.

Optionally, a conversation scene at dusk lets the fishers talk. Any agreement
to fish moderately then emerges purely as language in the agents' memories.
Nothing in the code enforces it.

The model uses only Concordia prefabs (no custom Game Master):

| Part | Prefab |
| --- | --- |
| Fishers (Alice, Bob, Charlie) | `prefabs.entity.basic` |
| Backstories as memories | `formative_memories_initializer` |
| Fishing Game Master (choice, then Python payoff) | `game_theoretic_and_dramaturgic` |
| Dusk Game Master (free-text conversation) | `dialogic_and_dramaturgic` |

## Files

| File | Purpose |
| --- | --- |
| `lobster_bay.py` | Multi-backend version: KoboldCpp, any OpenAI-compatible server, or any other Concordia `api_type`. |
| `lobster_bay-koboldcpp.py` | Original version, for KoboldCpp only. |

Both versions contain the same simulation. They differ only in how they talk to
a language model. If you only use KoboldCpp, either file works.

## Requirements

- Python 3.10 or newer
- `gdm-concordia` (tested with 2.4.0), `requests` and `sentence-transformers`

```bash
pip install gdm-concordia sentence-transformers requests
```

`sentence-transformers` is only needed if you use the default embedder. You can
avoid it by letting the model server provide the embeddings (see below).

## Quick start

Check the installation first, without any language model:

```bash
python lobster_bay.py --dry-run
```

The dry run makes random choices and uses a tiny hash-based embedder. It is
only a smoke test and produces no meaningful behaviour.

## Option 1: KoboldCpp (default)

Start KoboldCpp with a GGUF model, then run the simulation:

```bash
koboldcpp --model your-model.gguf --port 5001 --contextsize 16384
python lobster_bay.py --talk
```

Useful variations:

```bash
# Different server address, and embeddings from KoboldCpp
# (KoboldCpp must be started with --embeddingsmodel <file.gguf>)
python lobster_bay.py --talk --kobold-url http://localhost:5001 \
    --max-context 16384 --kobold-embeddings
```

`--max-context` must not exceed the `--contextsize` of KoboldCpp. Multiple-choice
answers (the number of traps) are produced with a GBNF grammar, so the output
is always a valid option.

## Option 2: Any OpenAI-compatible server

Use `--api-type openai-compatible` together with `--base-url` (including the
`/v1` part) and `--model-name`. This covers most local and hosted services.

```bash
# Ollama
python lobster_bay.py --talk --api-type openai-compatible \
    --base-url http://localhost:11434/v1 --model-name llama3.1:8b

# LM Studio
python lobster_bay.py --talk --api-type openai-compatible \
    --base-url http://localhost:1234/v1 --model-name local-model

# llama.cpp server or vLLM: use their /v1 address, for example
#   --base-url http://localhost:8080/v1     (llama.cpp server)
#   --base-url http://localhost:8000/v1     (vLLM)

# OpenAI (or OpenRouter: --base-url https://openrouter.ai/api/v1)
export LLM_API_KEY=sk-...
python lobster_bay.py --talk --api-type openai-compatible \
    --base-url https://api.openai.com/v1 --model-name gpt-4o-mini
```

The API key is read from `--api-key` or, if that is missing, from the
environment variable `LLM_API_KEY`. Local servers usually need no key.

### Embeddings

By default the agents' memories are embedded locally with
`sentence-transformers/all-mpnet-base-v2` (downloaded on first use). To use the
server instead, pass an embedding model that the server offers:

```bash
python lobster_bay.py --talk --api-type openai-compatible \
    --base-url http://localhost:11434/v1 --model-name llama3.1:8b \
    --embedding-model nomic-embed-text
```

### How choices work on other servers

KoboldCpp can force a valid answer with a grammar. Most other servers cannot,
so the script asks the model to reply with exactly one option, parses the reply
and retries up to three times with a slightly higher temperature. If the reply
is still unusable, it picks an option at random and prints a message. Watch the
console for such messages: frequent random picks mean the model is too small or
does not follow instructions well.

Reasoning models that print long thinking text before the answer may be cut off
by the short answer limit. A standard (non-reasoning) chat model works best.

## Option 3: Other Concordia backends

Any other `api_type` known to `concordia.contrib.language_models` (for example
`gemini`) can be used with `--api-type` and `--model-name`:

```bash
python lobster_bay.py --talk --api-type gemini --model-name <model> --api-key <key>
```

Check the Concordia documentation for the `api_type` names and the
authentication each of them expects.

## Command line options

| Option | Default | Meaning |
| --- | --- | --- |
| `--api-type` | `koboldcpp` | `koboldcpp`, `openai-compatible`, or a Concordia `api_type` |
| `--model-name` | none | Model of the chosen API (not needed for KoboldCpp) |
| `--api-key` | `LLM_API_KEY` | API key, if the service needs one |
| `--base-url` | `http://localhost:11434/v1` | Endpoint for `openai-compatible` |
| `--embedding-model` | none | Use the server's `/embeddings` endpoint with this model |
| `--kobold-url` | `http://localhost:5001` | KoboldCpp server address |
| `--max-context` | `16384` | Context size used by the model wrapper |
| `--kobold-embeddings` | off | Embed via KoboldCpp instead of `sentence-transformers` |
| `--days` | `7` | Number of simulated days |
| `--talk` | off | Add the dusk conversation scene |
| `--seed` | `0` | Seed for the bay (who fishes first each day) |
| `--dry-run` | off | No LLM: random choices and a hash embedder |
| `--html` | `lobster_bay_log.html` | Name of the HTML log file |

## Output

The console shows the traps set per day (Alice/Bob/Charlie), the remaining
stock and the final money of each fisher. The full run is written to an HTML
log (`lobster_bay_log.html` by default) that contains every observation,
prompt-driven action and Game Master event. Expect a very large amount of text,
because every observation is stored in memory and each step triggers many LLM
calls.

## Changing the world

The parameters are constants at the top of the script:

| Constant | Default | Meaning |
| --- | --- | --- |
| `START_STOCK` | 120 | Lobsters at the start (also the maximum) |
| `REGROWTH` | 0.10 | Share of the remaining stock that regrows each night |
| `MAX_TRAPS` | 10 | Maximum traps per fisher per day |
| `PRICE` | 5 | Pounds earned per lobster |
| `FISHERS` | Alice, Bob, Charlie | Names and short identities, used for the backstories |

## Tips

- Runs with `--talk` take much longer than runs without it, because the fishers
  also converse every evening.
- Single runs are only plausible stories, not evidence. For analysis, repeat the
  runs with different seeds and prompt wordings, and look at the logged
  grounded variables (stock, traps and money) as well as the text.
- Small local models may ignore instructions or drift away from the scenario.
  If the results look odd, try a larger model before changing the code.
- Responses are not fully reproducible, even with a fixed `--seed`, because the
  seed only controls the bay and is passed to the model server where supported.

## Troubleshooting

| Message | Likely cause |
| --- | --- |
| `Cannot reach KoboldCpp at ...` | KoboldCpp is not running, or `--kobold-url` is wrong |
| `Cannot reach ...` (OpenAI-compatible) | Wrong `--base-url`, or the server is not running. Remember the `/v1` part. |
| `Access denied by ... (check --api-key)` | Missing or invalid API key |
| `Could not parse a choice, picking at random` | The model does not answer with one of the options. Try another model. |
| HTTP 404 from the server | The `--model-name` is not available on the server, or the endpoint path is wrong |
| Out-of-memory or very slow runs | Reduce `--max-context` (and the server context size), use a smaller model, or fewer `--days` |

## Licence and credits

Built on Concordia by Google DeepMind. Please check the licences of Concordia
and of the language models you use.
