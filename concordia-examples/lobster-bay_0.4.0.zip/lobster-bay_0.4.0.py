"""Lobster Bay: a commons dilemma with Concordia (gdm-concordia 2.x).

Three LLM fishers share one bay. Each day every fisher chooses how many traps
to set. The lobster stock, catches and money are grounded variables kept in
Python (class `LobsterBay`). Optionally, a conversation scene at dusk lets the
fishers talk, so a shared rule can emerge in language.

Design (no custom Game Master needed, only Concordia prefabs):
  * fishers:     `prefabs.entity.basic` (LLM agents with components)
  * set-up:      `formative_memories_initializer` (backstories as memories)
  * fishing GM:  `game_theoretic_and_dramaturgic` (choice -> Python payoff)
  * dusk GM:     `dialogic_and_dramaturgic` (free-text conversation)
  * scenes:      per day one fishing scene, then (optional) one dusk scene

Tested with gdm-concordia 2.4.0 (dry run). Three kinds of backend:
  * koboldcpp (default): a local KoboldCpp server (native /api/v1/generate
    endpoint, with GBNF grammars for multiple-choice answers).
  * openai-compatible: any server that offers the OpenAI chat completions API
    (LM Studio, Ollama, llama.cpp server, vLLM, OpenAI, OpenRouter, ...).
  * any other `api_type` known to `concordia.contrib.language_models`.

Usage:
  pip install gdm-concordia sentence-transformers requests
  python lobster_bay.py --dry-run                      # offline smoke test

  # Start KoboldCpp first, e.g.:
  #   koboldcpp --model your-model.gguf --port 5001 --contextsize 16384
  python lobster_bay.py --talk                         # real run via KoboldCpp
  python lobster_bay.py --talk --kobold-url http://localhost:5001 \
      --max-context 16384 --kobold-embeddings           # embeddings from Kobold
                                                       # (needs --embeddingsmodel)

  # Any OpenAI-compatible server (examples):
  python lobster_bay.py --talk --api-type openai-compatible \\
      --base-url http://localhost:11434/v1 --model-name llama3.1:8b       # Ollama
  python lobster_bay.py --talk --api-type openai-compatible \\
      --base-url http://localhost:1234/v1 --model-name local-model        # LM Studio
  python lobster_bay.py --talk --api-type openai-compatible \\
      --base-url https://api.openai.com/v1 --model-name gpt-4o-mini \\
      --api-key sk-...                                  # or set LLM_API_KEY
"""

import argparse
import hashlib
import os
import random
import re

import numpy as np
import requests

from concordia.components.game_master import make_observation
from concordia.contrib import language_models
from concordia.language_model import language_model as lm_lib
from concordia.language_model import no_language_model
from concordia.prefabs.entity import basic as basic_entity
from concordia.prefabs.game_master import dialogic_and_dramaturgic as dusk_gm
from concordia.prefabs.game_master import formative_memories_initializer as init_gm
from concordia.prefabs.game_master import game_theoretic_and_dramaturgic as fishing_gm
from concordia.prefabs.simulation import generic as simulation
from concordia.typing import entity as entity_lib
from concordia.typing import prefab as prefab_lib
from concordia.typing import scene as scene_lib

# ----------------------------- World parameters -----------------------------
START_STOCK = 120      # Lobsters in the bay at the start (also the maximum).
REGROWTH = 0.10        # Share of the remaining stock that regrows each night.
MAX_TRAPS = 10         # Traps a fisher may set per day (0..MAX_TRAPS).
PRICE = 5              # Pounds earned per lobster.

FISHERS = {            # Name -> identity, used as context for the backstory.
    'Alice': 'a cautious third-generation fisher who values the bay\'s future.',
    'Bob': 'a pragmatic fisher with a bank loan to repay.',
    'Charlie': 'an ambitious young fisher who wants to buy a bigger boat.',
}
FISHING_GM, DUSK_GM, INIT_GM = 'fishing rules', 'conversation rules', 'setup rules'
WORLD_FACTS = [
    'Alice, Bob and Charlie share Lobster Bay, the only lobster ground nearby.',
    f'Each lobster sells for {PRICE} pounds. The lobsters regrow slowly.',
    'If the bay is fished empty, nobody can earn a living from it.',
]


class LobsterBay:
    """Grounded state: lobster stock, money and the day counter (in Python).

    The Game Master only sees what these methods choose to say, so the exact
    stock stays hidden from the fishers (partial information).
    """

    def __init__(self, names, seed=0):
        self.names = list(names)
        self.rng = random.Random(seed)
        self.stock = START_STOCK
        self.day = 1
        self.money = {n: 40 for n in self.names}
        self.last = None      # Report of the last resolved day.
        self.history = []     # One record per day, for analysis.
        self.talk = False     # Set by the caller: is there a dusk scene?

    # -- Rules ---------------------------------------------------------------
    def fishing_scores(self, joint_action):
        """Resolve one day. Called by the GM once all fishers have chosen.

        Args:
          joint_action: fisher name -> chosen number of traps (as text).
        Returns:
          fisher name -> income of the day in pounds (the GM's "score").
        """
        traps = {n: min(MAX_TRAPS, int(re.search(r'\d+', str(a)).group()))
                 for n, a in joint_action.items()}
        catch, order = {}, list(traps)
        self.rng.shuffle(order)  # Random initiative: who fishes first matters.
        for n in order:
            catch[n] = min(traps[n], self.stock)
            self.stock -= catch[n]
            self.money[n] += catch[n] * PRICE
        self.stock = min(START_STOCK, self.stock + round(self.stock * REGROWTH))
        self.last = {'traps': traps, 'catch': catch}
        self.history.append(
            {'day': self.day, 'traps': traps, 'catch': catch,
             'stock': self.stock})
        self.day += 1
        return {n: catch[n] * PRICE for n in catch}

    # -- Partial information, as text ---------------------------------------
    def _bay_look(self):
        share = self.stock / START_STOCK
        return ('The bay looks full of lobsters' if share > 0.75 else
                'The bay looks a little less full than before' if share > 0.5
                else 'The bay looks thin' if share > 0.25
                else 'The bay looks almost empty')

    @staticmethod
    def _load(traps):
        return 'a light' if traps <= 3 else 'a moderate' if traps <= 6 else 'a heavy'

    def report(self, name):
        """What `name` learns about the previous day (own catch, others' loads)."""
        if not self.last:
            return ''
        others = '; '.join(
            f'{n} brought in {self._load(t)} load'
            for n, t in self.last['traps'].items() if n != name)
        return (f'Yesterday you caught {self.last["catch"][name]} lobsters and '
                f'now have {self.money[name]} pounds. At the quay you saw that '
                f'{others}. {self._bay_look()}.')

    def morning(self, name):
        """Scene premise (callable): the start of a fishing day."""
        text = f'Day {self.day}, 06:00. You may set 0 to {MAX_TRAPS} traps today.'
        if not self.talk:
            text += ' ' + self.report(name)
        return text.strip()

    def dusk(self, name):
        """Scene premise (callable): the fishers meet at the quay in the evening."""
        return ('At dusk the three fishers meet at the quay and can talk. '
                + self.report(name))


# -------------------------------- Simulation --------------------------------
def build_config(bay, days, talk):
    """Build the Concordia config: prefabs, instances and the scene list."""
    names = list(FISHERS)
    fishing = scene_lib.SceneTypeSpec(
        name='fishing', game_master_name=FISHING_GM,
        action_spec=entity_lib.choice_action_spec(
            call_to_action='How many lobster traps will {name} set today?',
            options=[str(i) for i in range(MAX_TRAPS + 1)]))
    dusk = scene_lib.SceneTypeSpec(
        name='dusk', game_master_name=DUSK_GM,
        action_spec=entity_lib.free_action_spec(
            call_to_action=entity_lib.DEFAULT_CALL_TO_SPEECH))

    # Note: Concordia counts one "round" per individual action, so a scene in
    # which every fisher acts once has num_rounds=len(names).
    scenes = []
    for _ in range(days):
        scenes.append(scene_lib.SceneSpec(
            scene_type=fishing, participants=names, num_rounds=len(names),
            premise={n: [bay.morning] for n in names}))
        if talk:  # Every fisher speaks once.
            scenes.append(scene_lib.SceneSpec(
                scene_type=dusk, participants=names, num_rounds=len(names),
                premise={n: [bay.dusk] for n in names}))

    # One queue shared by both GMs so that premises queued by one GM are
    # delivered by whichever GM acts next (otherwise the dusk report is late).
    queue = make_observation.ObservationQueue()
    prefabs = {'fisher': basic_entity.Entity(), 'init': init_gm.GameMaster(),
               'fishing': fishing_gm.GameMaster(), 'dusk': dusk_gm.GameMaster()}
    instances = [prefab_lib.InstanceConfig(
        prefab='fisher', role=prefab_lib.Role.ENTITY,
        params={'name': n, 'goal': f'Earn a living from Lobster Bay as {FISHERS[n]}'})
        for n in names]
    instances.append(prefab_lib.InstanceConfig(
        prefab='init', role=prefab_lib.Role.INITIALIZER,
        params={'name': INIT_GM, 'next_game_master_name': FISHING_GM,
                'shared_memories': WORLD_FACTS,
                'player_specific_context': {
                    n: f'{n} is {FISHERS[n]}' for n in names}}))
    instances.append(prefab_lib.InstanceConfig(
        prefab='fishing', role=prefab_lib.Role.GAME_MASTER,
        params={'name': FISHING_GM, 'scenes': scenes, 'external_queue': queue,
                'action_to_scores': bay.fishing_scores,
                # Observations come from scene premises, so queue none here.
                'scores_to_observation': lambda scores: {}}))
    if talk:
        instances.append(prefab_lib.InstanceConfig(
            prefab='dusk', role=prefab_lib.Role.GAME_MASTER,
            params={'name': DUSK_GM, 'scenes': scenes,
                    'external_queue': queue}))
    return prefab_lib.Config(
        prefabs=prefabs, instances=instances,
        default_premise='Lobster Bay, early autumn. Three fishers share the bay.',
        default_max_steps=60 * days)


class KoboldCppLanguageModel(lm_lib.LanguageModel):
    """Concordia language model backed by a KoboldCpp server.

    Uses the native KoboldCpp endpoint POST /api/v1/generate. Multiple-choice
    questions are answered with a GBNF grammar, so the output is always one of
    the allowed options (no parsing failures, no retries).
    """

    def __init__(self, base_url='http://localhost:5001', max_context=16384,
                 timeout=600, default_temperature=0.7):
        self._url = base_url.rstrip('/')
        self._max_context = max_context
        self._timeout = timeout
        self._temperature = default_temperature
        self._rng = random.Random(0)
        try:
            r = requests.get(f'{self._url}/api/v1/model', timeout=10)
            r.raise_for_status()
            print('KoboldCpp model:', r.json().get('result'))
        except Exception as e:  # Fail early with a clear message.
            raise SystemExit(f'Cannot reach KoboldCpp at {self._url}: {e}')

    def _generate(self, prompt, max_length, stop=(), temperature=None,
                  top_p=0.95, top_k=64, seed=None, grammar=None, timeout=None):
        payload = {
            'prompt': prompt,
            'max_context_length': self._max_context,
            'max_length': max(1, int(max_length)),
            'temperature': self._temperature if temperature is None else temperature,
            'top_p': top_p,
            'top_k': top_k,
            'rep_pen': 1.05,
            'stop_sequence': list(stop)[:16],  # KoboldCpp allows at most 16.
        }
        if seed is not None:
            payload['sampler_seed'] = int(seed)
        if grammar:
            payload['grammar'] = grammar
            payload['grammar_retain_state'] = False
        r = requests.post(f'{self._url}/api/v1/generate', json=payload,
                          timeout=timeout or self._timeout)
        r.raise_for_status()
        return r.json()['results'][0]['text']

    def sample_text(self, prompt, *, max_tokens=5000, terminators=(),
                    temperature=None, top_p=0.95, top_k=64, timeout=None,
                    seed=None):
        # Keep the reply within the context window, leaving room for the prompt.
        max_tokens = min(int(max_tokens), max(64, self._max_context // 4))
        text = self._generate(prompt, max_tokens, stop=terminators,
                              temperature=temperature, top_p=top_p,
                              top_k=top_k, seed=seed, timeout=timeout)
        for t in terminators:  # Safety net if the server kept a terminator.
            if t and t in text:
                text = text[:text.index(t)]
        return text

    @staticmethod
    def _gbnf_literal(s):
        s = s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')
        return f'"{s}"'

    def sample_choice(self, prompt, responses, *, seed=None):
        responses = list(responses)
        if not responses:
            raise ValueError('responses must not be empty')
        # A trailing newline makes "1" and "10" unambiguous for the grammar.
        use_nl = not any('\n' in r for r in responses)
        alts = ' | '.join(self._gbnf_literal(r) for r in responses)
        grammar = f'root ::= ({alts})' + (' "\\n"' if use_nl else '')
        max_len = max(len(r) for r in responses) + 2  # tokens <= characters.
        text = ''
        try:
            text = self._generate(prompt, max_len, stop=['\n'] if use_nl else [],
                                  temperature=0.2, seed=seed,
                                  grammar=grammar).strip()
        except requests.RequestException as e:
            print('KoboldCpp grammar request failed, picking at random:', e)
        if text in responses:
            idx = responses.index(text)
        else:  # Grammar unsupported or unexpected output: closest prefix, else random.
            hits = [i for i, r in enumerate(responses) if text and r.startswith(text)]
            idx = hits[0] if hits else self._rng.randrange(len(responses))
        return idx, responses[idx], {'raw_output': text, 'grammar': grammar}


class OpenAICompatibleLanguageModel(lm_lib.LanguageModel):
    """Concordia language model for any OpenAI-compatible chat API.

    Works with LM Studio, Ollama (/v1), the llama.cpp server, vLLM, OpenAI,
    OpenRouter and similar services. Multiple-choice questions are answered by
    asking the model to reply with one option and parsing the reply (a few
    retries, random choice as the last resort), because most servers offer no
    grammar-constrained output.
    """

    def __init__(self, base_url, model_name, api_key=None, timeout=600,
                 default_temperature=0.7, max_context=16384):
        self._url = base_url.rstrip('/')
        self._model = model_name
        self._timeout = timeout
        self._temperature = default_temperature
        self._max_context = max_context
        self._rng = random.Random(0)
        self._headers = {'Content-Type': 'application/json'}
        if api_key:
            self._headers['Authorization'] = f'Bearer {api_key}'
        try:  # Fail early with a clear message.
            r = requests.get(f'{self._url}/models', headers=self._headers,
                             timeout=15)
        except requests.RequestException as e:
            raise SystemExit(f'Cannot reach {self._url}: {e}')
        if r.status_code in (401, 403):
            raise SystemExit(f'Access denied by {self._url} (check --api-key).')
        print('Connected to', self._url, '| model:', self._model)

    def _chat(self, prompt, max_tokens, stop=(), temperature=None, top_p=None,
              seed=None, timeout=None):
        payload = {
            'model': self._model,
            'messages': [{'role': 'user', 'content': prompt}],
            'max_tokens': max(1, int(max_tokens)),
            'temperature': self._temperature if temperature is None else temperature,
        }
        if top_p is not None:
            payload['top_p'] = top_p
        if stop:
            payload['stop'] = list(stop)[:4]  # OpenAI allows at most 4.
        if seed is not None:
            payload['seed'] = int(seed)
        url = f'{self._url}/chat/completions'
        r = requests.post(url, headers=self._headers, json=payload,
                          timeout=timeout or self._timeout)
        if r.status_code == 400:
            # Some models (e.g. reasoning models) reject sampling parameters
            # or `max_tokens`: retry with the bare minimum.
            minimal = {'model': self._model, 'messages': payload['messages'],
                       'max_completion_tokens': payload['max_tokens']}
            r = requests.post(url, headers=self._headers, json=minimal,
                              timeout=timeout or self._timeout)
        r.raise_for_status()
        return r.json()['choices'][0]['message'].get('content') or ''

    def sample_text(self, prompt, *, max_tokens=5000, terminators=(),
                    temperature=None, top_p=0.95, top_k=64, timeout=None,
                    seed=None):
        # Keep the reply within the context window, leaving room for the prompt.
        max_tokens = min(int(max_tokens), max(64, self._max_context // 4))
        text = self._chat(prompt, max_tokens, stop=terminators,
                          temperature=temperature, top_p=top_p, seed=seed,
                          timeout=timeout)
        for t in terminators:  # Servers may ignore `stop`: trim ourselves.
            if t and t in text:
                text = text[:text.index(t)]
        return text

    @staticmethod
    def _match(text, responses):
        """Index of the option that `text` names, or None."""
        text = text.strip().strip('.!"\'` ')
        if text in responses:
            return responses.index(text)
        best = None  # (position, -length, index): earliest, then longest.
        for i, r in enumerate(responses):
            m = re.search(r'(?<![\w.])' + re.escape(r) + r'(?!\w)', text)
            if m and (best is None or (m.start(), -len(r)) < best[:2]):
                best = (m.start(), -len(r), i)
        return None if best is None else best[2]

    def sample_choice(self, prompt, responses, *, seed=None):
        responses = list(responses)
        if not responses:
            raise ValueError('responses must not be empty')
        ask = (prompt.rstrip() + '\n\nReply with exactly one of these options '
               'and nothing else: ' + ' | '.join(responses))
        max_len = 8 + 2 * max(len(r) for r in responses)
        text, idx = '', None
        for attempt in range(3):
            try:
                text = self._chat(ask, max_len, temperature=0.2 + 0.4 * attempt,
                                  seed=None if seed is None else seed + attempt)
            except requests.RequestException as e:
                print('Chat request failed:', e)
                continue
            idx = self._match(text, responses)
            if idx is not None:
                break
        if idx is None:  # Unusable output: random choice, but say so.
            print('Could not parse a choice, picking at random. Raw output:',
                  repr(text[:80]))
            idx = self._rng.randrange(len(responses))
        return idx, responses[idx], {'raw_output': text}


def openai_embedder(base_url, model_name, api_key=None):
    """Embedder using an OpenAI-style /embeddings endpoint."""
    url = base_url.rstrip('/') + '/embeddings'
    headers = {'Content-Type': 'application/json'}
    if api_key:
        headers['Authorization'] = f'Bearer {api_key}'

    def embed(text):
        r = requests.post(url, headers=headers, timeout=120,
                          json={'input': text, 'model': model_name})
        r.raise_for_status()
        return np.array(r.json()['data'][0]['embedding'], dtype=np.float32)
    return embed


def kobold_embedder(base_url, dim_hint=None):
    """Embedder using KoboldCpp's OpenAI-style /v1/embeddings endpoint.

    Requires starting KoboldCpp with --embeddingsmodel <file.gguf>.
    """
    url = base_url.rstrip('/') + '/v1/embeddings'

    def embed(text):
        r = requests.post(url, json={'input': text, 'model': 'koboldcpp'},
                          timeout=120)
        r.raise_for_status()
        return np.array(r.json()['data'][0]['embedding'], dtype=np.float32)
    return embed


def hash_embedder(text, dim=64):
    """Tiny deterministic embedder for offline dry runs (not semantic)."""
    vec = np.zeros(dim)
    for token in text.lower().split():
        vec[int(hashlib.md5(token.encode()).hexdigest(), 16) % dim] += 1
    return vec / (np.linalg.norm(vec) or 1.0)


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument('--api-type', default='koboldcpp',
                   help="'koboldcpp' (default), 'openai-compatible' or any "
                        "concordia api_type")
    p.add_argument('--model-name', default=None,
                   help='model of the chosen API (not needed for koboldcpp)')
    p.add_argument('--api-key', default=None,
                   help='API key (default: environment variable LLM_API_KEY)')
    p.add_argument('--base-url', default='http://localhost:11434/v1',
                   help="endpoint of the 'openai-compatible' API, including /v1")
    p.add_argument('--embedding-model', default=None,
                   help="embed via the 'openai-compatible' /embeddings endpoint "
                        "with this model instead of sentence-transformers")
    p.add_argument('--kobold-url', default='http://localhost:5001',
                   help='base URL of the KoboldCpp server')
    p.add_argument('--max-context', type=int, default=16384,
                   help='must not exceed KoboldCpp --contextsize')
    p.add_argument('--kobold-embeddings', action='store_true',
                   help='embed via KoboldCpp (/v1/embeddings) instead of '
                        'sentence-transformers')
    p.add_argument('--days', type=int, default=7)
    p.add_argument('--talk', action='store_true', help='add the dusk conversation')
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--dry-run', action='store_true',
                   help='no LLM: random choices, hash embedder')
    p.add_argument('--html', default='lobster_bay_log.html')
    args = p.parse_args()

    use_kobold = args.api_type == 'koboldcpp'
    use_openai = args.api_type == 'openai-compatible'
    api_key = args.api_key or os.environ.get('LLM_API_KEY')
    if not args.dry_run and not use_kobold and not args.model_name:
        p.error('--model-name is required for this --api-type')
    if args.dry_run:
        model, embedder = no_language_model.RandomChoiceLanguageModel(), hash_embedder
    else:
        if use_kobold:
            model = KoboldCppLanguageModel(args.kobold_url, args.max_context)
        elif use_openai:
            model = OpenAICompatibleLanguageModel(
                args.base_url, args.model_name, api_key,
                max_context=args.max_context)
        else:
            model = language_models.language_model_setup(
                api_type=args.api_type, model_name=args.model_name,
                api_key=api_key)
        if args.kobold_embeddings:
            embedder = kobold_embedder(args.kobold_url)
        elif args.embedding_model:
            embedder = openai_embedder(args.base_url, args.embedding_model, api_key)
        else:
            from sentence_transformers import SentenceTransformer
            st = SentenceTransformer('sentence-transformers/all-mpnet-base-v2')
            embedder = lambda text: st.encode(text, show_progress_bar=False)

    bay = LobsterBay(FISHERS, seed=args.seed)
    bay.talk = args.talk
    config = build_config(bay, args.days, args.talk)
    sim = simulation.Simulation(config=config, model=model, embedder=embedder)
    log = sim.play()

    print('\nDay  traps (A/B/C)  stock')
    for h in bay.history:
        print(f'{h["day"]:>3}  {"/".join(str(t) for t in h["traps"].values()):>13}'
              f'  {h["stock"]:>5}')
    print('Money:', bay.money)
    with open(args.html, 'w', encoding='utf-8') as f:
        f.write(log.to_html())
    print('Log written to', args.html)


if __name__ == '__main__':
    main()
